# codility-binarygap
Find longest sequence of zeros in binary representation of an integer.

# codility-cylicrotation
Rearrange an array to the right based on the number of steps given

# codility-OddOccurencesInArray
Given an array, find a value that has no duplication. I scored 100% for it.

# codility-FrogJmp
FrogJmp is the third lesson number 1 out of three in the list for Time Complexity algorithm. Basically, it is an algorithm to count the number of the jump from one X location to Y location when the number of the step taken is given as Z for each single jump

# codility-PermMissingElem
This is a lesson in codility for the Time Complexity algorithm. Given an array of integer, you need to find the lowest missing integer.

# codility-TapeEquilibrium
Given an array of int (ranging from -ve to +ve value) with the minimum number of an element is 2 and the maximum element is 100,000, you need to find the lowest difference between two sets of value (of the total sum of the array)

# codility-FrogRiverOne
Find the earliest time when a frog can jump to the other side of a river. This is the fourth lesson in Codility. You need to find the fastest (earliest) time possible for a frog to start jumping towards the other side of the river. You will be given an array that reflecting the position of jumping/landing point for the frog.

# codility-PermCheck
This is the second lesson in Codility. Given an array of integer N, you need to find if the given array is a permutation array or perfect array in sequence (if all numbers are sorted accordingly). The full explanation of the lesson is at https://app.codility.com.
